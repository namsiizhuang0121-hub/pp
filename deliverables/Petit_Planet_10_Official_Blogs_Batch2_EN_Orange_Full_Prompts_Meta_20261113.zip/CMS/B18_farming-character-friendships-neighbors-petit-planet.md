# Farming and Character Friendships: Getting to Know Petit Planet’s Neighbors

If farming and character friendships are both part of what you want from a life sim, Petit Planet brings those interests together. Farming and befriending Neighbors are core activities in HoYoverse’s cozy galactic life sim, which launches globally on PC and mobile on December 4, 2026. The official introduction to Yunguo offers one concrete character-focused way to begin exploring its world.

## A farming interest can begin with a character

In the [official Neighbor introduction](https://planet.hoyoverse.com/en-us/home), Yunguo is presented as a cultivator who carefully checks on her crops. One sentence captures the care behind that introduction: “She wants them to grow strong, so everyone can enjoy a hearty harvest.”

That detail gives a familiar life-sim activity a personal connection. Farming is part of the game’s activity list, and here an official character introduction expresses an interest in growing things and sharing the result.

For readers who notice characters first, this is a specific reason to be curious. A personality and an everyday interest can make a world feel approachable before you have learned all of its terms.

## Neighbors are the characters you get to know

Befriending Neighbors is one of Petit Planet’s core activities. These are the characters you get to know in the game.

When choosing a farming life sim, consider how much character interest matters to you. You may enjoy an activity on its own, or find that people within the setting help draw you in. Official introductions are a useful starting point for exploring that preference.

Yunguo gives you an example to begin with: a named character whose introduction connects with farming. As you follow the game, notice which introductions make you want to understand the setting around them.

## Everyday activities provide the surrounding life

Petit Planet includes farming, fishing, beachcombing, gathering, and cooking. Planet building and decorating are also core activities, and players tend their own small planet.

Those facts give character interest a wider context. A Neighbor belongs to a life-sim world where everyday activities and a personal place are central to the premise.

If you are drawn to the combination of farming and characters, think about which parts catch your attention separately. An activity may be familiar, while a character introduction makes you curious about the life around it.

## The world extends beyond your planet

Players travel the Starsea to discover other worlds. Exploration sites there are called Islets, distinct from the planet you tend.

This gives your interest another direction: a personal place, characters to know, and a wider galactic setting. You can be curious about a Neighbor while also wanting to discover the world that frames planet life.

There is a separate player-social side as well. Playing with friends is a core activity, and the Galactic Bazaar is where players meet friends. Neighbors and player friends are different parts of the experience.

## Start with a detail that interests you

For character-focused players, a small official detail can be a useful introduction to a new game. Yunguo’s care for a harvest is one such starting point; your curiosity may lead you toward other Neighbors, everyday activities, or the Starsea. Visit the [official website](https://planet.hoyoverse.com/en-us/home) to learn more and pre-register ahead of December 4.
