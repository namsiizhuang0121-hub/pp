# Like Farming and Social Features? Meet Friends in Petit Planet

If you like farming and social features, Petit Planet brings both into a cozy galactic life sim: farming, befriending Neighbors, and playing with friends are core activities. Players meet friends at the Galactic Bazaar. Developed and published by HoYoverse, the game launches globally on PC and mobile on December 4, 2026.

Social features can mean different things to different players. Getting to know a character and meeting another player are separate interests, and understanding that distinction is a useful way to explore Petit Planet.

## Farming is part of everyday planet life

Farming sits alongside fishing, beachcombing, gathering, and cooking in the core activity list. It is one way into a broader life-sim experience that also includes creativity, exploration, and friendships.

For a player drawn to farming, the useful question is what you enjoy having around it. You may want characters to know, a personal place to shape, or a game you can follow with friends. Those preferences help explain why the social side matters to you.

## Neighbors are the characters you befriend

Befriending Neighbors is a core activity in Petit Planet. These are the characters you get to know in the game.

This is the character-focused meaning of social play. If a life sim appeals because of its inhabitants, start with the official Neighbor introductions. A character who catches your attention can give you another reason to become interested in planet life alongside farming or decorating.

Think about whether characters are something you notice first or something you enjoy discovering as you learn about the wider setting. Either preference can guide which official introductions you explore.

## The Galactic Bazaar is where players meet friends

Playing with friends is also part of Petit Planet’s core gameplay. The Galactic Bazaar is the place where players meet friends.

This is the player-focused side of the social premise. If you are considering the game with friends, discuss which activities and parts of the world interest each of you. Your curiosity may start in different places while still giving you a game to follow together.

The two kinds of friendship fit into the same life sim: Neighbors are characters, while the friends you meet at the Galactic Bazaar are other players. Keeping the names clear makes the setting easier to understand.

## A personal planet gives those interests a setting

Players tend their own small planet, with planet building and decorating among the core activities. This gives farming and the wider planet-life experience a personal center.

If creativity matters alongside social interests, include that in your decision. You might enjoy imagining a place of your own while also being curious about characters and friends. Petit Planet connects these interests through its cozy galactic premise.

## There is a world beyond home, too

Players travel the Starsea to discover other worlds. Its exploration sites are called Islets, distinct from the planet you tend.

That adds discovery to the picture alongside farming, creativity, and friendship. As you explore the game’s official introductions, ask which combination appeals to you: everyday activities and characters, a personal planet and friends, or an interest in all of them.

Visit the [official Petit Planet website](https://planet.hoyoverse.com/en-us/home) to learn more and pre-register ahead of December 4. Start with the kind of social experience you are curious about, then discover how it sits within planet life.
