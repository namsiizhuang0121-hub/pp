# Farming Games on Mobile: Discover Petit Planet on iOS and Android

Looking for farming games on mobile? Petit Planet is an upcoming cozy galactic life sim that includes farming alongside planet decorating, everyday activities, and friendships. Developed and published by HoYoverse, it launches globally on PC and mobile on December 4, 2026, with the App Store announced for iOS and Google Play for Android.

For a mobile player, two questions are useful to consider together: where you expect to play and which parts of planet life interest you. Here is an introduction to both.

## Farming is part of a wider mobile life-sim experience

Farming is one of Petit Planet’s core activities. Fishing, beachcombing, gathering, and cooking are also part of the everyday activity mix.

If farming first draws your attention, look at which other activities you would like alongside it. You may be curious about cooking, interested in fishing, or want to discover what beachcombing adds to the setting. Those preferences can help you decide what you would like to learn about first.

The appeal is a combination of life-sim interests within the same cozy galactic world. Your starting interest can be familiar while another part makes you curious.

## Your phone’s planet-life setting includes a personal place

Players tend their own small planet, with planet building and decorating among the core activities. For someone who enjoys creativity beside farming, this is another part of the experience to follow.

Think about whether making a place your own matters to your game choice. You might be drawn to the atmosphere of the setting or enjoy imagining a decorating idea. Petit Planet gives that interest a personal planet at the center of its premise.

## Neighbors and friends are part of the activity mix

Befriending Neighbors and playing with friends are core activities. Neighbors are the characters you get to know in the game; players meet friends at the Galactic Bazaar.

If social features are part of what you want from a mobile life sim, consider both meanings of friendship. You might want to discover characters or be curious about following the game with friends. Keeping those interests separate helps explain what you are looking for.

## There is also a Starsea beyond home

Players travel the Starsea to discover other worlds. Its exploration sites are called Islets, distinct from the planet you tend.

That gives a mobile farming interest a wider setting to explore. Everyday planet life, creativity, friendships, and discovery are all part of the same galactic premise.

## Check the announced platform and date

Petit Planet launches globally on PC and mobile on December 4, 2026. Announced channels include the App Store for iOS and Google Play for Android, alongside HoYoPlay and the Epic Games Store for PC. A Nintendo Switch 2 version is planned for 2027.

Before launch, visit the [official website](https://planet.hoyoverse.com/en-us/home) to explore the game and pre-register through the announced channels. Begin with the device you expect to use, then follow the activities that catch your attention. Farming may be your introduction to Petit Planet; a planet of your own, Neighbors, friends, or the Starsea may give you another reason to learn more.
