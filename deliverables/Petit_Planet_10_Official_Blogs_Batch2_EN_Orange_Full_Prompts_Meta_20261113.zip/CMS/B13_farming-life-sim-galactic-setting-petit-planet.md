# Looking for a Farming Life Sim with a Different Setting? Petit Planet Goes Galactic

If you enjoy Stardew Valley and are looking for a farming life sim with a different setting, Petit Planet combines familiar everyday activities with a cozy galactic world. Developed and published by HoYoverse, it includes farming, fishing, gathering, cooking, planet building and decorating, friendships, and Starsea exploration. It launches globally on PC and mobile on December 4, 2026.

The connection begins with activities you recognize. The change in setting begins with the place you tend: your own small planet.

## Farming within a wider life sim

Farming is one of Petit Planet’s core activities. It sits alongside fishing, beachcombing, gathering, and cooking, so it is useful to think about the everyday activity mix as well as the farming interest that first caught your attention.

You might be drawn to farming but also want to discover what a game offers around it. In Petit Planet, the announced activity list gives you several directions to explore within the same cozy setting.

A helpful question is which activity you would like to get to know first, followed by which one you would be curious about next. This makes your reasons for considering a game specific.

## Your own small planet changes the setting

Players tend their own small planet, where planet building and decorating are part of the experience. A personal place and a creative activity therefore belong together in the premise.

If you enjoy the idea of making a home within a game world, this is a distinctive reason to follow Petit Planet. You are looking at familiar life-sim interests in a galactic setting, with a planet of your own at its center.

Think about whether creativity is part of what you want beside farming. Some players are excited by the activity itself; others also want to imagine a place that expresses their preferences.

## The Starsea takes discovery beyond home

Players travel the Starsea to discover other worlds. Exploration sites there are called Islets, distinct from the planet you tend.

This gives the world an understandable shape: a personal planet is home, while the Starsea is the wider area you explore. For someone interested in both everyday life and discovery, that relationship is part of Petit Planet’s galactic appeal.

## Characters and player friends offer separate interests

Befriending Neighbors and playing with friends are both core activities. Neighbors are the characters you get to know in the game; the Galactic Bazaar is where players meet friends.

If social features matter to your choice, look at both meanings of friendship. Getting to know characters may be important to you, or you may be curious about making the game a shared interest with friends. Those preferences can help you decide which introductions to follow.

## How to decide whether the mix appeals to you

Consider four things: the activities you enjoy, the place you would like to make your own, your curiosity about the wider world, and the kind of company you want in a life sim. Petit Planet connects those interests through planet life, Neighbors, the Starsea, and the Galactic Bazaar.

Before its December 4 launch, visit the [official website](https://planet.hoyoverse.com/en-us/home) to learn more and pre-register. Start with a familiar activity, then discover which part of the galactic setting makes you curious to stay and look around.
