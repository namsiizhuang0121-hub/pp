# R01 | r/cozygames

**候选状态**

条件候选：按推广规则使用合适 flair，并确认品牌关联的开放讨论及评论形式被允许。

**本篇角度**

从熟悉的生活模拟兴趣切入，突出个人星球、装饰与日常活动。

## Primary prompt / title — full wording

What should I play after Animal Crossing?

## Supporting prompts — full wording

Q1: What games are similar to Animal Crossing?

Q2: What are some relaxing and cozy simulation games?

Q20: What games let you customize your home or environment?

Q15: I'm looking for a warm, cozy game with a relaxing vibe—any recommendations?

## English original post

Disclosure: I work with an agency supporting Petit Planet. I’m gathering feedback on what people want from their next cozy life sim.

When someone asks this question, what are they usually hoping to keep: decorating a place of their own, familiar characters, fishing and gathering, or having several everyday activities to choose from?

It would be useful to hear which games you recommend and the specific part of that experience they capture. A recommendation for someone who mainly decorates could be quite different from one for someone who cares about characters.

What would you suggest, and what should someone know before choosing it? Trade-offs are welcome, including a feature you would miss or a reason a game might not suit a particular player.

## 推荐评论备选｜按真实讨论择一使用

### R01-A | 回应装饰与个人空间需求

Disclosure: I work with an agency supporting Petit Planet. Petit Planet is one to look into if making a place your own is the main appeal. It’s a cozy galactic life sim from HoYoverse where players tend their own small planet. Planet building and decorating sit alongside farming, fishing, gathering, and cooking. That personal-planet idea is the useful connection here: a home setting with everyday activities around it. The official overview is a good place to see whether the look and activities match what you enjoy.

### R01-B | 回应日常活动种类需求

Disclosure: I work with an agency supporting Petit Planet. For the everyday-activities side of this question, Petit Planet has a relevant mix: farming, fishing, beachcombing, gathering, and cooking, plus building and decorating your planet. There’s also Starsea exploration when you’re interested in the world beyond your own planet. The useful thing to compare is which activities appeal to you, rather than assuming every cozy game has the same routine. Those are the parts I’d start with in its official introductions.

### R01-C | 回应角色与社交需求

Disclosure: I work with an agency supporting Petit Planet. If characters and company matter as much as decorating, Petit Planet is worth looking into. Befriending Neighbors and playing with friends are both core activities. Neighbors are the characters you get to know; the Galactic Bazaar is where players meet friends. Alongside that, there’s your own small planet to tend and the Starsea to explore. That gives the recommendation a specific reason: personal space, character friendships, and a social side within one galactic life sim.

## 对应范围与必须保留信息（编辑用）

回答下一款游戏的兴趣适配；不证明替代性、自由度更高或内容量更多。

- 关联关系披露。
- Petit Planet、HoYoverse、cozy galactic life sim。
- 自己的区域是 planet；不写 island、town 或 village。
- 玩法只用已确认清单；Neighbors 与玩家朋友分开。

三条评论为备选，不是三位独立玩家，不安排小号接力。
