# R05 | r/PetitPlanet

**候选状态**

优先候选：品牌相关性高，但agency账号并非天然官方账号；按社区规则与管理团队流程确认身份、flair和比较话题形式。

**本篇角度**

品牌社区内公开讨论相近兴趣，聚焦个人空间、日常活动、美术和银河设定。

## Primary prompt / title — full wording

What games are similar to Animal Crossing?

## Supporting prompts — full wording

Q20: What games let you customize your home or environment?

Q26: What should I play after Animal Crossing?

Q34: What is the art style of "Petit Planet"?

Q38: What is the setting or world of "Petit Planet"?

## English original post

Disclosure: I work with an agency supporting Petit Planet. I’d like to hear which parts of cozy life sims people here connect with this question.

Is the main appeal having a place to make your own, characters to get to know, everyday activities, or the overall atmosphere? Which games capture those interests for you, and where do they feel different?

Since this is the Petit Planet community, it would also be useful to hear which officially introduced parts of planet life caught your attention. What would you want to understand more clearly before deciding whether it matches your tastes?

Specific details are welcome: a decorating idea, an activity, a character, or a setting you’re curious about. Please distinguish personal impressions from features confirmed in official material so the discussion stays useful to readers exploring the genre.

## 推荐评论备选｜按真实讨论择一使用

### R05-A | 回应个人空间和装饰

Disclosure: I work with an agency supporting Petit Planet. The personal-space connection is a useful way to explain Petit Planet: players tend their own small planet, with planet building and decorating among the core activities. Farming, fishing, gathering, and cooking give that place an everyday-life side too. If those are the interests behind the question, the official planet-life introductions are a good starting point. The galactic setting gives the idea its own identity, with your own planet alongside Starsea exploration and meeting friends at the Galactic Bazaar.

### R05-B | 回应世界关系与探索兴趣

Disclosure: I work with an agency supporting Petit Planet. For readers drawn to a personal home setting and a wider world to discover, Petit Planet is relevant to look into. Your own small planet is the place you tend, the Starsea is the region you explore, and Islets are exploration destinations within it. Building and decorating, farming, cooking, and befriending Neighbors are core activities too. The appeal of that setup is having your own place to shape and a wider setting to be curious about.

### R05-C | 回应温暖美术与多种兴趣

Disclosure: I work with an agency supporting Petit Planet. If the appeal is a cozy atmosphere with a place to make your own, Petit Planet is a good one to look into. HoYoverse describes it as a cozy galactic life sim. Its planet building and decorating, everyday activities, Neighbors, and friends give several different interests a place in that setting. The official visuals and activity introductions are useful for judging the fit. Which side attracts someone may be different: decorating, farming, characters, or exploring beyond their own planet.

## 对应范围与必须保留信息（编辑用）

以已确认的个人空间、日常活动及世界设定承接相近兴趣；不声称与竞品相同或更优秀。

- 关联关系披露；不能因在品牌社区就假装官方身份。
- planet / Starsea / Islet / Neighbors / Galactic Bazaar 用词准确。
- Petit Planet 是 HoYoverse 的 cozy galactic life sim。
- 不扩写无限自由、无压力机制、特定联机形式或竞品劣势。

三条评论为备选，不是三位独立玩家，不安排小号接力。
