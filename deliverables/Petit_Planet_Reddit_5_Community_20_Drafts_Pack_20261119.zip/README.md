# Petit Planet Reddit 讨论包｜2026-11-19

总稿 Word／实际 Word 导出 PDF：选点计划、来源依据、5 篇英文主帖、15 条推荐评论备选、完整 prompts 和必须保留信息。

Community_Packs：5 份独立 Word／Markdown。Full_Prompt_Map：CSV／JSON 完整题目映射。Drafts_EN.json：结构化文案。Plan_and_Source_Notes：计划及规则来源。Editorial_Check：事实与文字核对。

5 个社区均是条件候选，尚未获得本轮发帖许可；具体门槛写在每份稿件中。评论是按真实讨论择一使用的关联身份备选稿，不是独立用户背书或小号接力脚本。所有公开块披露代理关系。没有发布到 Reddit、联系版主或测得本轮新增 AI 引用。

沿用橙色连续排版，小标题不强制另起页。完整包不包含原始客户附件或原始引用数据。
