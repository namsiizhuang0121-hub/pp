# Petit Planet Reddit｜5 个社区讨论包

2026-11-19｜5 篇主帖＋15 条推荐评论备选｜橙色连续排版

## 本轮方案与使用方式

采用公开品牌合作关系的讨论方式：由真实负责项目的人说明身份、提出有信息价值的问题，再按实际讨论补充一条相关的品牌事实回复。主帖不直接推荐产品，披露中出现品牌名；允许社区提出其他游戏、不同偏好和批评。

15 条评论是每题 3 种可择一使用的备选稿，不是 15 位玩家的评价，也不是安排其他账号接力背书的脚本。实际评论需回应当时的真实问题；在自己发起的线程跟进，应由同一已披露身份继续补充。

标题逐字使用原始 prompts：Q26、Q23、Q25、Q10、Q1。4 题带竞品名，1 题带 best；best 是向玩家提问的主观选择标准，不作为 Petit Planet 的排名结论。与此前官网稿不同，这批是社区讨论稿，因此保留这些原题词。

所有帖子均为英文待审核稿。没有编造游玩经历、下载状态、独立玩家身份或用户评价；没有发帖、评论或联系版主。公开 GitHub 仅提供交付文件下载。

## 五个社区的选择与当前可执行性

R01｜r/cozygames｜Q26。优先候选：主题直接吻合。公开规则限制同游戏过度推广，通常不应多于每两周一次，并禁止假装无关联；需按实际帖型使用 flair，核对品牌近期记录。来源：[社区规则栏](https://www.reddit.com/r/cozygames/)。

R02｜r/LifeSimulators｜Q23。条件候选：关联内容需披露及正确 flair，重复推广和缺乏实质人工贡献的 AI 写作可被移除。该社区另有自己的类型判定；现有事实卡不足以证明满足其全部标准。先确认独立主帖资格；若仅允许周度线程，就改用其中一条相关评论，不能声称仍有独立标题。来源：[规则栏](https://www.reddit.com/r/LifeSimulators/)／[类型标准公告](https://www.reddit.com/r/LifeSimulators/comments/1of61ie/)。

R03｜r/FarmingGames｜Q25。条件候选：种田新手主题贴合，规则允许有限自推、约每周一次，4 周内重复内容可被移除。不过读取到的社区状态为 Restricted，仅批准用户可以贡献；本轮没有核实账号资格。先取得贡献权限，再判断独立主帖形式。来源：[规则与社区状态](https://www.reddit.com/r/FarmingGames/)／[版主讨论说明](https://www.reddit.com/r/FarmingGames/comments/y3asfy/)。

R04｜r/MobileGaming｜Q10。暂缓推广：其 Rule 5 欢迎游戏讨论和反馈，但明确不允许 promotional posts 与 download links。本稿不能直接作为推广帖投放，须确认公开关联的真实讨论与事实回复形式被接受；未确认时保留为备用稿。来源：[Rule 5](https://www.reddit.com/r/MobileGaming/)。

R05｜r/PetitPlanet｜Q1。优先候选：直接面向品牌兴趣社区。仍需遵守推广许可、恰当 flair、来源与 AI 内容标记等要求；代理人员并不天然拥有官方账号或版主身份。来源：[社区规则栏](https://www.reddit.com/r/PetitPlanet/)。

这五个是匹配题意的候选，不是五个已获准发帖位。版规与页面可能来自近期缓存，实际发布时应核对现行规则、置顶帖和账号权限。规则不允许时放弃该位置，不通过换账号或把推广移到评论里规避。

## 为什么不直接选历史被引社区

r/CozyGamers 虽在历史引用中多次出现，其开发者规则不允许泛泛的品牌营销调查或 soft advertising；本批提问式 OP 不放这里。r/gamingsuggestions 的推广限制同样不能通过主帖无品牌、评论再植入来绕开。

r/AndroidGaming 的推广标题须带 [DEV]，推荐请求另有 [REQUEST] 格式，且不允许 surveys/questionnaires/polls。它与本轮逐字标题和品牌调研 OP 的要求不吻合，因此改选 r/FarmingGames 作为 Q25 的条件候选。

r/iosgaming 的旧暂停公告与较新开发者展示线程并存，需要按当周条件判断；不能直接把旧的周六自推经验用于本项目。官方渠道公布也不等于现在可下载。

## 如何借鉴已被引用的写法

复核了已提供的 Reddit 正文、cited-source 匹配、基线与后续 visibility report，并对照以前的品牌官网内容导出。基线与后续报告显示的核心问题仍是非品牌推荐中的发现缺口，因此本轮优先用相近作品与选择标准承接需求。没有据此承诺新增引用。

Reddit 样本常见结构是：主帖交代具体活动偏好与平台；评论先给游戏名，再解释对应玩法和差异，必要时说明限制。引用记录定位到讨论串，不能确定 AI 引的是哪一条评论，也不能证明这种写法造成引用。本批没有照搬原楼主的生活经历、游戏时长或试玩口吻。

此前官网导出中的 Plarium 相近游戏／手机种田文章采用‘先给选择标准，再解释每个选项的理由’；Nintendo 的短时场景与 Square Enix 的播客场景文章把需求连到具体活动。这里沿用需求到事实的连接方式，不沿用它们的极端排名、时长、操作体验或未经确认的本作功能。

推荐评论的事实核心按题区分：Q26 侧重个人星球与日常活动；Q23 侧重种田之外的银河设定；Q25 侧重新人可以了解的活动和耐力事实；Q10 侧重种田、角色与手机渠道；Q1 侧重装饰与世界关系。避免 15 条只是重复同一广告段落。

标题逐字对应有助于编辑核对题意，但 AI 是否引用还取决于页面可访问、检索相关性、答案质量和引擎选择。安排多条同品牌评论、获得点赞或原帖曾经被引，都不等于新评论会被引用。

## 发布与复盘流程

先由真实执行者补充有意义的编辑判断，确认其角色、权限与本帖对社区的价值。尤其 LifeSimulators 的 AI 写作规则需要实质人工贡献；不能只是删掉披露就把草稿当作真人原创直接复制。

从已确认允许的一个社区、一个讨论主题开始。主帖公开关系、允许开放答案；有真实问题需要产品信息时，再从三个评论版本中选择相关的一条修改。没有问题需要补充时，不为凑评论数发三遍推荐。

按实际需要保留一个官方信息来源：[Petit Planet 官网](https://planet.hoyoverse.com/en-us/home)。外链需遵守对应社区规则；不得编造商店地址、使用镜像、推荐码或在禁下载链接的位置放下载链接。

复盘记录分开保存：线程 URL 与可见状态、真实用户提出的问题、品牌事实是否准确，以及后续同一 prompt/引擎测到的回答和引用 URL。只有明确出现品牌相关句与来源，才能记录为本轮观察到的提及／引用；不把评论数等同 GEO 效果。统计口径按项目后续统一要求执行，本轮不另建评分。

## 必须保留的产品事实边界

Petit Planet 的拼写、HoYoverse、cozy galactic life sim，以及按题使用的 planet building and decorating、farming、fishing、beachcombing、gathering、cooking、befriending Neighbors、exploring the Starsea、playing with friends。

玩家经营的是自己的 planet；Starsea 是外出探索区域，Islets 是探索目的地；Neighbors 是角色，Galactic Bazaar 是见玩家朋友的地方。有耐力机制。

不把放松定位写成无耐力、无任务压力、不肝、非 pay-to-win、无限内容；不把朋友游玩写成共建农场、同屏或跨端；不由角色友谊推导恋爱、婚姻或强剧情。已公布渠道不等于已可玩。保持不写 upcoming、发行日期或定档宣传。

本批没有必要讨论商业化；若实际评论问及，使用已确认 F8 句并按当时官方信息核对，不自行扩写价格、商品种类或付费公平承诺。

## 历史引用样本（不是当前投放位置）

[相近作品与差异需求](https://www.reddit.com/r/CozyGamers/comments/1gcqehp/a_game_for_stardew_valley_lovers_but_different/)。档案 reddit-03；Q11／Google AI Overview。 区分玩家想保留的兴趣与想尝试的新设定；不复制个人经历。

[把相似拆成具体生活模拟兴趣](https://www.reddit.com/r/StardewValley/comments/1424jxb/im_searching_for_other_games_like_stardew_valley/)。档案 reddit-65；Q10、Q27／Google AI Overview。 一句活动偏好，加一个具体推荐理由。被匹配 Q27 不证明本作更放松。

[装饰需求与可自定义的空间](https://www.reddit.com/r/gamingsuggestions/comments/1x9mbaf/looking_for_cozy_games_that_have_a_big_focus_on/)。档案 reddit-75；Q20／Perplexity。 说明可以布置什么，以及关联的生活活动。仅作结构参考，非获准推广位置。

[带 best 的手机种田问题](https://www.reddit.com/r/AndroidGaming/comments/1b5dxco/whats_the_best_farming_games_at_the_moment/)。档案 reddit-30；Q5／Perplexity。 标题之外仍需具体标准。原帖的付费公平要求并非本作已证明的优势。

[种田与社交需求的区别](https://www.reddit.com/r/harvestmoon/comments/18b6gwg/what_game_will_i_like_if_i_like_the_social/)。档案 reddit-19；Q14／Perplexity。 分开说明角色与玩家朋友。原帖平台不匹配，不作为本轮回复目标。
