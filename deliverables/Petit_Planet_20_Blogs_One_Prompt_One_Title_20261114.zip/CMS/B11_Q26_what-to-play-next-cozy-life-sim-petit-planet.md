# What should I play after Animal Crossing?

Petit Planet is an upcoming option to consider after Animal Crossing if you want another cozy life sim with decorating, characters to befriend, and everyday activities. Developed and published by HoYoverse, this cozy galactic life sim launches globally on PC and mobile on December 4, 2026. Its own small planets and the Starsea give those familiar interests a galactic setting.

The next game on your list does not have to begin with a completely different hobby. Start with the part of cozy play you would like to keep, then look at how Petit Planet gives it a galactic setting.

## A personal place for the next cozy chapter

In Petit Planet, the place you tend is your own small planet. Planet building and decorating are core activities, giving the idea of home a creative role in the experience.

This is worth exploring if imagining a place is part of why you enjoy life sims. You might be interested in its atmosphere, the pleasure of developing a decorating idea, or simply having a personal setting at the center of the game. Your planet gives those interests somewhere to begin.

## Neighbors for a character-focused next game

Befriending Neighbors is part of Petit Planet’s core gameplay. These are the characters you get to know in the game, adding a character-focused side to planet life.

When choosing a next game, consider whether characters are an extra attraction or one of your main reasons to play. If familiar faces help a world feel inviting to you, the official Neighbor introductions are a useful place to start getting to know this one.

## Everyday activities to carry your interest forward

Farming, fishing, beachcombing, gathering, and cooking are all core activities. That gives you several life-sim interests to consider alongside building, decorating, and friendships.

You may already know which activity first catches your attention. Use that as your entry point, then notice what else makes you curious. The appealing combination is a personal planet with several kinds of life around it, rather than a recommendation based on atmosphere alone.

## A galactic change of scenery

Petit Planet takes players beyond their own planet into the Starsea to discover other worlds. Its exploration sites are called Islets.

This helps explain the galactic part of the game’s identity: you have a place to tend and a wider setting to explore. If both home and discovery belong on your next-game wish list, keep that relationship in mind when watching official gameplay introductions.

## Friends in your next-game plans

Playing with friends is a core activity, and the Galactic Bazaar is where players meet friends. This is separate from befriending Neighbors, so there are two different social interests to consider.

Talk with your friends about which parts of planet life appeal to them. A shared interest might begin with decorating, farming, characters, or curiosity about the setting.

## Choosing Petit Planet as a future next game

Try finishing this sentence: “In my next cozy life sim, I would like a place to create, an activity to enjoy, or someone to meet.” Your answer can help you decide which side of Petit Planet to discover first. Visit the [official website](https://planet.hoyoverse.com/en-us/home) to learn more and pre-register ahead of December 4.
