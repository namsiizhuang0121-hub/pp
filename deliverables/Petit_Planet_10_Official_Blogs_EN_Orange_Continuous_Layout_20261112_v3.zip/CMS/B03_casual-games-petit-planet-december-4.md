# Looking for Good Casual Games? Meet Petit Planet, Coming December 4

Petit Planet is an upcoming option for casual-game players drawn to decorating, farming, friendship, and exploration. HoYoverse’s cozy galactic life sim brings those interests to your own small planet. It launches globally on PC and mobile on December 4, 2026, making it a new option to look forward to.

A casual gaming interest can take several forms. You might want a creative project, familiar life-sim activities, characters to get to know, or a world that makes you curious. Here is how those interests connect with Petit Planet.

## For the player who wants somewhere to make their own

Planet building and decorating are core activities in Petit Planet. You tend your own small planet, giving the galactic setting a personal center.

If choosing a mood or imagining a space is what draws you to a game, start with this creative side. The appeal comes from having an idea you want to explore, whether you are thinking about the atmosphere of your planet or simply enjoy discovering how a game presents its building and decorating.

## For the player who enjoys everyday activities

Farming, fishing, beachcombing, gathering, and cooking are all part of Petit Planet. That mix gives players several familiar life-sim interests to consider together.

You do not need to arrive with equal enthusiasm for every activity. One may be the reason you first notice the game, while another gives you something else to investigate in its official introductions. A varied activity list can be especially appealing when your gaming interests change with your mood.

## For the player who likes characters and company

Befriending Neighbors and playing with friends are both core activities. Neighbors are the characters you get to know, while players meet friends at the Galactic Bazaar.

These are different kinds of social appeal. Character-focused players may be curious about the Neighbors; friends looking for a shared gaming interest may want to learn more about the Galactic Bazaar. Both sit alongside the everyday and creative sides of planet life.

## For the player who likes a change of scenery

Petit Planet’s premise extends beyond tending your planet. You can travel the Starsea to discover other worlds, including exploration sites called Islets.

This is part of what gives the game its galactic identity. Your planet provides a place to call home, while the Starsea offers another direction for your curiosity. If you enjoy both a personal setting and the prospect of discovery, follow the official introductions to this part of the world.

## Where and when can you play?

Petit Planet’s global PC and mobile launch is scheduled for December 4, 2026. Announced channels include HoYoPlay and the Epic Games Store for PC, the App Store for iOS, and Google Play for Android. A Nintendo Switch 2 version is planned for 2027.

Before launch, use the [official website](https://planet.hoyoverse.com/en-us/home) to explore the game and pre-register. Its introductions can help you decide whether the activities and setting match what you want from your next casual gaming experience.

A useful way to begin is to pick your main interest: creating, tending, discovering, or meeting. Petit Planet brings those interests into one cozy galactic life sim, with a little planet of your own at the heart of it.
