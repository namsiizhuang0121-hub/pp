# Petit Planet 官网博客包｜v2 PDF 核对版

2026-11-12

审阅总稿：10 篇英文正文＋完整目标 prompts＋Meta description＋中文必须保留信息。

Blogs 文件夹：10 份独立 Word，每份均有完整 prompts、Meta description、编辑说明及英文正文。

CMS 文件夹：10 篇纯英文正文的 Markdown 和 HTML；HTML 已含对应 Meta description，没有内部 prompts 和编辑说明，尚未部署官网。

Metadata CSV／JSON：便于集中核对标题、完整 prompts 和 Meta description。Self_Check 是逐篇自查结果；Report_Review_and_Changes 是 PDF 核对与修订说明。

监测原题不改写；其中个别排名词不代表本文的产品排名结论。正文不按性别划定受众。

发布时只使用英文正文，中文编辑区、prompt、参考竞品来源和 CMS 建议不随正文上线。建议 slug 并非已存在的网页，不应当作来源链接。

已有相近页面时，优先更新、替换或合并内容。本包的 B05–B10 不默认要求各新增一个 URL；B08 重点是玩法种类与耐玩评估，B09 重点是个人空间和舒适偏好。

正文以可读取的 HTML 文本输出，使用真实 H1／H2 和正常站内链接，用户可阅读。SSR 可用于输出正文，不能只给爬虫一份用户看不到的 FAQ／博客。

独立页面可按实际类型采用 Article／BlogPosting；结构化数据与可见正文一致，不把整篇博客机械标为 FAQPage，不虚构作者、上线日期、截图或实际 URL。

如配图，应使用已获使用权且与正文主张一致的官方画面。游戏画面版本、caption 和 alt 以实际素材为准，不代编截图事实。

12 月 4 日后发布时核对实际上线状态并更新未来时态。上线后仍不自动获得内容量、耐玩度、热门排名或合作方式的证明。

发布后沿用项目既定 prompts 和引擎复测实际提及与引用；本文案没有进行效果测试，也不保证 AI 平台引用。